<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Multiplication Table</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
/* Custom font to mimic the screenshot's font style */
body {
font-family: serif;
}
</style>
</head>
<body class="bg-white p-6 flex justify-center">
<div class="max-w-xs w-full">
<h1 class="text-3xl font-bold mb-4">Multiplication Table</h1>
<table class="border border-yellow-400 border-collapse w-full text-center text-sm">
<tbody>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">1</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">1</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">3</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">5</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">7</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">8</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">9</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">10</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">10</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">10</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">9</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">4</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">8</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">10</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">12</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">14</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">16</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">18</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">20</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">3</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">6</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">9</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">12</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">15</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">18</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">21</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">24</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">27</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">30</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">4</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">8</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">12</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">16</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">20</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">24</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">28</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">32</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">36</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">5</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">10</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">15</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">20</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">25</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">30</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">35</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">40</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">45</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">50</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">12</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">18</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">24</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">30</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">36</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">42</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">48</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">54</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">60</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">7</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">14</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">21</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">28</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">35</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">42</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">49</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">56</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">63</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">70</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">8</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">16</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">24</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">32</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">40</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">48</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">56</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">64</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">72</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">9</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">18</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">27</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">36</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">45</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">54</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">63</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">72</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">81</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">90</td>
</tr>
<tr>
<td class="border border-yellow-400 bg-yellow-300 px-1">0</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">10</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">20</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">30</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">40</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">50</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">60</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">70</td>
<td class="border border-yellow-400 bg-red-600 text-yellow-300 px-1">80</td>
<td class="border border-yellow-400 bg-yellow-300 px-1">100</td>
</tr>
</tbody>
</table>
</div>
</body>
</html>