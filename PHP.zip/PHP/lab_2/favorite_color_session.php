<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION["colors"] = [
        $_POST["color1"],
        $_POST["color2"],
        $_POST["color3"],
        $_POST["color4"],
        $_POST["color5"]
    ];
    header("Location: display_colors.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Favorite Colors</title>
</head>
<body>
    <form method="post">
        Favorite color 1: <input type="text" name="color1"><br>
        Favorite color 2: <input type="text" name="color2"><br>
        Favorite color 3: <input type="text" name="color3"><br>
        Favorite color 4: <input type="text" name="color4"><br>
        Favorite color 5: <input type="text" name="color5"><br>
        <input type="submit" value="Send Colors">
    </form>
</body>
</html>
