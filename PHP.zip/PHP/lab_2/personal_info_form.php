<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $middlename = $_POST["middlename"];
    $lastname = $_POST["lastname"];
    $dob = $_POST["dob"];
    $address = $_POST["address"];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Personal Information</title>
</head>
<body>
    <h2>Personal Information Form</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        First Name: <input type="text" name="firstname"><br><br>
        Middle Name: <input type="text" name="middlename"><br><br>
        Lastname: <input type="text" name="dob"><br><br>
        date of Birth: <input type="text" name="lastname"><br><br>
        Address: <input type="text" name="address"><br><br>
        <input type="submit" value="Submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo "<h3>Submitted Information:</h3>";
        echo "First Name: " . htmlspecialchars($firstname) . "<br>";
        echo "Middle Name: " . htmlspecialchars($middlename) . "<br>";
        echo "Lastname: " . htmlspecialchars($dob) . "<br>";
        echo "date of Birth: " . htmlspecialchars($lastname) . "<br>";
        echo "Address: " . htmlspecialchars($address) . "<br>";
    }
    ?>
</body>
</html>
