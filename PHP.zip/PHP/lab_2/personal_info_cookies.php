<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    setcookie("firstname", $_POST["firstname"], time() + 10);
    setcookie("middlename", $_POST["middlename"], time() + 20);
    setcookie("lastname", $_POST["lastname"], time() + 30);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Personal Info with Cookies</title>
    <link rel="stylesheet" href="../PHP/lab_2/favorite_color_session.php">
    <link rel="stylesheet" href="../PHP/lab_2/display_colors.php">
</head>
<body>
    <form method="post">
        First Name: <input type="text" name="firstname"><br>
        Middle Name: <input type="text" name="middlename"><br>
        Last Name: <input type="text" name="lastname"><br>
        <input type="submit" value="Submit">
    </form>
    <a href="http:/PHP/lab_2/display_colors.php">click me for display_colors</a>
    <a href="http:/PHP/lab_2/favorite_color_session.php">fav colors</a>

    <h2>Cookie Values</h2>
    <?php
    if (isset($_COOKIE["firstname"])) {
        echo "First Name: " . $_COOKIE["firstname"] . "<br>";
    }
    if (isset($_COOKIE["middlename"])) {
        echo "Middle Name: " . $_COOKIE["middlename"] . "<br>";
    }
    if (isset($_COOKIE["lastname"])) {
        echo "Last Name: " . $_COOKIE["lastname"] . "<br>";
    }
    ?>
</body>
</html>
