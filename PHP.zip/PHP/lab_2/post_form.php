<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['name']) && isset($_POST['age'])) {
    $name = htmlspecialchars($_POST['name']);
    $age = htmlspecialchars($_POST['age']);
    echo "<h2>POST Method Result:</h2>";
    echo "Name: $name<br>";
    echo "Age: $age<br>";
}
?>

<form method="post" action="">
    <label>Name: <input type="text" name="name" required></label><br>
    <label>Age: <input type="number" name="age" required></label><br>
    <input type="submit" value="Submit via POST">
</form>
