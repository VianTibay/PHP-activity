<?php
if (isset($_GET['name']) && isset($_GET['age'])) {
    $name = htmlspecialchars($_GET['name']);
    $age = htmlspecialchars($_GET['age']);
    echo "<h2>GET Method Result:</h2>";
    echo "Name: $name<br>";
    echo "Age: $age<br>";
}
?>

<form method="get" action="">
    <label>Name: <input type="text" name="name" required></label><br>
    <label>Age: <input type="number" name="age" required></label><br>
    <input type="submit" value="Submit via GET">
</form>
