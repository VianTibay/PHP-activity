<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Display Favorite Colors</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Your Favorite Colors</h2>
    <?php
    if (isset($_SESSION["colors"])) {
        foreach ($_SESSION["colors"] as $color) {
            echo "<div class='color-box' style='background-color: $color;'>$color</div>";
        }
    } else {
        echo "No colors set.";
    }
    ?>
</body>
</html>
